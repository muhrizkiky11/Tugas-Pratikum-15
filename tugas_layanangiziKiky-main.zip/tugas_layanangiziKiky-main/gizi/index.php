<?php 
header("Location:gizi.php");
 ?>