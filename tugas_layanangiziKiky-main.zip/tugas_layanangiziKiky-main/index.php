<?php 
echo "<script> alert('halo selamat datang di website layanan rumah sakit bengkulu');
document.location.href='pasien/daftar.php';
</script>";
 ?>
 