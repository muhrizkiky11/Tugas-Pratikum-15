<?php


header("Location:ruangan.php");


?>